DEPENDENCIES:
	-node.js (npm)
	-mplayer
	
INSTALL:
1. Copy desired Music Files into "./music", they should have "Title" and "Artist" as ID3 Tag.
2. Start Server with "npm start".
3. If there are issues with not loadable Files or Tags, replace them and find proper ones.